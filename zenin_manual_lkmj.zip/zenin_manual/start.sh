chmod 777 ./ainj
chmod 777 ./busybox

export PREV_V=$(settings get global auto_time)
settings put global auto_time 0
export DATE=$(./busybox date +%s)
echo "uid: $(./busybox date +%s | tr '0123456789' '6789012345')" > '/sdcard/Android/data/com.axlebolt.standoff2/cache/LangSource_I2Languages_Ukrainian (Local).loc'
./busybox date -s @1771911118 &&
./ainj -lib zenc.so -lib2 sbu -pkg com.axlebolt.standoff2 -dl_memfd -hide_maps -hide_solist
./busybox date -s @$DATE
settings put global auto_time $PREV_V